import os
import tkinter as tk
from tkinter import filedialog
from tkinter import PhotoImage
from pytube import YouTube

def download_video(url, output_path):
    try:
        yt = YouTube(url)
        video = yt.streams.filter(progressive=True, file_extension='mp4').first()
        if video is not None:
            output_text.config(state=tk.NORMAL)
            output_text.insert(tk.END, "Downloading...\n")
            output_text.config(state=tk.DISABLED)
            video.download(output_path)
            output_text.config(state=tk.NORMAL)
            output_text.insert(tk.END, "Download complete!\n")
            output_text.config(state=tk.DISABLED)
        else:
            output_text.config(state=tk.NORMAL)
            output_text.insert(tk.END, "No suitable video format found.\n")
            output_text.config(state=tk.DISABLED)
    except Exception as e:
        output_text.config(state=tk.NORMAL)
        output_text.insert(tk.END, f"Error: {e}\n")
        output_text.config(state=tk.DISABLED)

def browse_url():
    youtube_url = url_entry.get()
    output_folder = filedialog.askdirectory()
    if youtube_url and output_folder:
        download_video(youtube_url, output_folder)


root = tk.Tk()
root.title("Bad quality YT to mp4 converter")
root.geometry("800x500")


icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
if os.path.exists(icon_path):
    root.iconphoto(True, PhotoImage(file=icon_path))


root.configure(bg="black")
root.option_add("*Font", "Consolas 10")
root.option_add("*Foreground", "white")
root.option_add("*Background", "black")
root.option_add("*selectForeground", "black")
root.option_add("*selectBackground", "white")


url_label = tk.Label(root, text="Enter YouTube URL:")
url_label.pack(pady=5)
url_entry = tk.Entry(root, width=70)
url_entry.pack(pady=5)


output_text = tk.Text(root, wrap=tk.WORD, height=15, state=tk.DISABLED)
output_text.pack(pady=10, padx=5)


browse_button = tk.Button(root, text="Browse", command=browse_url)
browse_button.pack(pady=10)


root.mainloop()



browse_button = tk.Button(root, text="Browse", command=browse_url)
browse_button.pack(pady=10)


root.mainloop()
